
Instructions for execution of the program Steps: 
----------------------------------------------
Step1: Set the java build path
Step2: clean and install the maven project
Step3: run the MainClass java application.
Step4: verify the result in console.

----------------------------------------------

