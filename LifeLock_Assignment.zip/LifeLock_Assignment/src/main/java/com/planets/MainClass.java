package com.planets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.planets.utility.Constants;
import com.planets.utility.PlannetJsonPaser;

/**
 * @author annadurai_a
 *
 */
public class MainClass {
	
	static {
		identifierPlannetsList = Arrays.asList(Constants.identifierPlannets);
	}
	static List<String> identifierPlannetsList;
	Map<Integer, Map<String, List<JsonObject>>> planetsDiscoveredMap = new TreeMap<Integer, Map<String, List<JsonObject>>>();
	List<JsonObject> orphanPlanetsList = new ArrayList<JsonObject>();
	List<JsonObject> identyfyPlanetsJsonList = new ArrayList<JsonObject>();
	final static Logger logger = Logger.getLogger(MainClass.class);
	String hotestStar = null;
	
	public static void main(String[] args) {
		new MainClass();
	}

	public MainClass() {
		execute();
	}

	private void execute() {
		
		/**
		 *  getDataFromEndPoint URL
		 */
		String jsonSting = getDataFromEndPoint(Constants.URL);

		/**
		 * getDataFrom JSON File
		 */
		//String jsonSting = getDataFromFile("/exoplanets.json");

		if (jsonSting != null) {
			PlannetJsonPaser plannet = new PlannetJsonPaser(jsonSting);
			JsonArray planetsJsonArray = plannet.getPlanetArray();
			double tempMax = 0.0;
			for (JsonElement jsonElement : planetsJsonArray) {
				if (jsonElement.isJsonObject()) {
					JsonObject planetObj = jsonElement.getAsJsonObject();
					/**
					 * The number of orphan planets (no star).
					 */
					if (!identifierPlannetsList.contains(planetObj.get(Constants.PLANET_IDENTIFIER).getAsString())) {
						orphanPlanetsList.add(planetObj);
					} else {
						identyfyPlanetsJsonList.add(planetObj);
					}

					/**
					 * The name (planet identifier) of the planet orbiting the hottest star.
					 */
					if (planetObj.get(Constants.HOST_STAR_TEMP_K).isJsonPrimitive()
							&& planetObj.get(Constants.HOST_STAR_TEMP_K).getAsJsonPrimitive().isNumber()) {
						double max = planetObj.get(Constants.HOST_STAR_TEMP_K).getAsDouble();
						if (max > tempMax) {
							tempMax = max;
							hotestStar = planetObj.get(Constants.PLANET_IDENTIFIER).getAsString();
						}
					}

					/**
					 * A timeline of the number of planets discovered per year grouped by size. Use
					 * the following groups: �small� is less than 1 Jupiter radii �medium� is less
					 * than 2 Jupiter radii anything bigger is considered �large� For example, in
					 * 2004 we discovered 2 small planets, 5 medium planets, and 0 large planets.
					 */
					if (planetObj.get(Constants.DISCOVERY_YEAR).isJsonPrimitive()
							&& planetObj.get(Constants.RADIUS_JPT).isJsonPrimitive()) {
						JsonPrimitive jsonPrimitiveYear = planetObj.get(Constants.DISCOVERY_YEAR).getAsJsonPrimitive();
						JsonPrimitive jsonPrimitiveRds = planetObj.get(Constants.RADIUS_JPT).getAsJsonPrimitive();
						if (jsonPrimitiveYear.isNumber() && jsonPrimitiveRds.isNumber()) {
							double radiusJpt = planetObj.get(Constants.RADIUS_JPT).getAsDouble();
							int discoveryYear = planetObj.get(Constants.DISCOVERY_YEAR).getAsInt();
							Map<String, List<JsonObject>> value = null;
							if (planetsDiscoveredMap.get(discoveryYear) == null) {
								value = new HashMap<String, List<JsonObject>>();
								planetsDiscoveredMap.put(discoveryYear, value);
							} else {
								value = planetsDiscoveredMap.get(discoveryYear);
							}
							if (radiusJpt < 1.0) {
								String small = Constants.SMALL;
								List<JsonObject> jsonObjects = null;
								if (value.get(small) == null) {
									jsonObjects = new ArrayList<JsonObject>();
									value.put(small, jsonObjects);
								} else {
									jsonObjects = value.get(small);
								}
								jsonObjects.add(planetObj);
							} else if (radiusJpt < 2.0) {
								String medium = Constants.MEDIUM;
								List<JsonObject> jsonObjects = null;
								if (value.get(medium) == null) {
									jsonObjects = new ArrayList<JsonObject>();
									value.put(medium, jsonObjects);
								} else {
									jsonObjects = value.get(medium);
								}
								jsonObjects.add(planetObj);
							} else {
								String large = Constants.LARGE;
								List<JsonObject> jsonObjects = null;
								if (value.get(large) == null) {
									jsonObjects = new ArrayList<JsonObject>();
									value.put(large, jsonObjects);
								} else {
									jsonObjects = value.get(large);
								}
								jsonObjects.add(planetObj);
							}

						}
					}
				}
			}
			if (logger.isInfoEnabled()) {
				logger.info(Constants.X_X);
				logger.info(getNumberOfOrphanPlanets());
				// logger.info(identyfyPlanetsJsonList.size());
				logger.info(Constants.X_X);
				logger.info(getHotestStar());
				logger.info(Constants.X_X);
			}
			for (Integer year : planetsDiscoveredMap.keySet()) {
				logger.info(getPlanetsDetails(year));
			}
			if (logger.isInfoEnabled()) {
				logger.info(Constants.X_X);
			}
		} else {
			if (logger.isInfoEnabled()) {
				logger.info("Data is not availble");
			}
		}

	}

	public String getNumberOfOrphanPlanets() {
		return "The Number of orphan planets : " + orphanPlanetsList.size();
	}

	public String getHotestStar() {
		return "Hotest Star : " + hotestStar;
	}

	public String getPlanetsDetails(Integer year) {
		Map<String, List<JsonObject>> map = planetsDiscoveredMap.get(year);
		if (map == null)
			return "In " + year + " we discovered 0 " + Constants.SMALL + " planets, 0 " + Constants.MEDIUM
					+ " planets, and 0 " + Constants.LARGE + " planets";

		String message = "In " + year + " we discovered "
				+ (map.get(Constants.SMALL) != null ? map.get(Constants.SMALL).size() : "0") + " " + Constants.SMALL
				+ " planets, " + (map.get(Constants.MEDIUM) != null ? map.get(Constants.MEDIUM).size() : "0") + " "
				+ Constants.MEDIUM + " planets, and "
				+ (map.get(Constants.LARGE) != null ? map.get(Constants.LARGE).size() : "0") + " " + Constants.LARGE
				+ " planets";
		return message;
	}

	public String getDataFromFile(String file) {
		try {
			InputStream inputStream = this.getClass().getResourceAsStream(file);
			if (inputStream == null)
				return null;
			return new BufferedReader(new InputStreamReader(inputStream)).lines().collect(Collectors.joining("\n"));
		} catch (Exception e) {
			logger.error("Error : " + e);
		}
		return null;

	}

	public static String getDataFromEndPoint(String urlStr) {
		try {
			URL url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoOutput(true);
			connection.setInstanceFollowRedirects(false);
			connection.setRequestMethod(Constants.GET);
			connection.setRequestProperty(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
			connection.setRequestProperty(Constants.CHARSET, Constants.UTF_8);
			connection.connect();
			InputStream inStream = connection.getInputStream();
			return streamToString(inStream);
		} catch (IOException e) {
			logger.error("Error connecting to the end point : " + e);
			logger.fatal("This is fatal : " + e);
		} catch (Exception e) {
			logger.error("Error : " + e);
		}
		return null;
	}

	@SuppressWarnings("resource")
	private static String streamToString(InputStream inputStream) {
		String text = new Scanner(inputStream, Constants.UTF_8).useDelimiter(Constants.Z).next();
		return text;
	}
}
