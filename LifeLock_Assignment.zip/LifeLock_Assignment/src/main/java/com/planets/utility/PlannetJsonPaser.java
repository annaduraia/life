package com.planets.utility;

import org.apache.log4j.Logger;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

/**
 * @author annadurai_a
 *
 */
public class PlannetJsonPaser {

	private JsonArray planetArray;

	final static Logger logger = Logger.getLogger(PlannetJsonPaser.class);

	@SuppressWarnings("deprecation")
	public PlannetJsonPaser(String jsonSting) throws JsonSyntaxException {
		try {
			JsonParser jsonParser = new JsonParser();
			JsonElement element = jsonParser.parse(jsonSting);
			if (element.isJsonArray()) {
				planetArray = element.getAsJsonArray();
			}
		} catch (JsonSyntaxException e) {
			logger.error("parsing error " + e);
			throw e;
		}
	}

	/**
	 * getPlanetArray()
	 * 
	 * @return
	 */
	public JsonArray getPlanetArray() {
		return planetArray == null ? new JsonArray() : planetArray;
	}

}
