package com.planets.utility;

/**
 * @author annadurai_a
 *
 */
public class Constants {

	public static final String[] identifierPlannets = { "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn",
			"Uranus", "Neptune" };

	public static final String URL = "https://gist.githubusercontent.com/joelbirchler/66cf8045fcbb6515557347c05d789b4a/raw/9a196385b44d4288431eef74896c0512bad3defe/exoplanets";

	public static final String PLANET_IDENTIFIER = "PlanetIdentifier";
	
	public static final String DISCOVERY_YEAR = "DiscoveryYear";

	public static final String RADIUS_JPT = "RadiusJpt";

	public static final String HOST_STAR_TEMP_K = "HostStarTempK";

	public static final String CONTENT_TYPE = "Content-Type";

	public static final String APPLICATION_JSON = "application/json";

	public static final String CHARSET = "charset";

	public static final String UTF_8 = "UTF-8";

	public static final String Z = "\\Z";

	public static final String GET = "GET";

	public static final String LARGE = "large";

	public static final String MEDIUM = "medium";

	public static final String SMALL = "small";

	public static final String X_X = "---------------------------------------------------------------";
}
