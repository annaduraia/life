/**
 * 
 */
package planets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

import com.planets.MainClass;
/**
 * 
 * @author annadurai_a
 *
 */
public class MainClassTest {

	MainClass mainClass;
	
	@Before
	public void start() {
		mainClass = new MainClass();
	}
	@Test
	public void testGetDataFromFilePath() {
		String jsonStr = mainClass.getDataFromFile("/exoplanets.json");
		//InputStream s = this.getClass().getResourceAsStream("/exoplanets.json");
		assertNotNull(jsonStr);
	}
	@Test
	public void testGetDataFromEndPointWrongFilePath() {
		String jsonString = mainClass.getDataFromFile("/exoplanetsnotfound.json");
		assertNull(jsonString);
	}
	
	@Test
	public void testGetPlanetsDetails() {
		String s = mainClass.getPlanetsDetails(2014);
		String expected = "In 2014 we discovered 830 small planets, 30 medium planets, and 0 large planets";
		assertEquals(expected , s);
	}
	
	@Test
	public void testGetPlanetsDetailsNotCovered() {
		String s = mainClass.getPlanetsDetails(2020);
		String expected = "In 2020 we discovered 0 small planets, 0 medium planets, and 0 large planets";
		assertEquals(expected , s);
	}
	
	@Test
	public void testGetNumberOfOrphanPlanets() {
		String s = mainClass.getNumberOfOrphanPlanets();
		String expected = "The Number of orphan planets : 3418";
		//InputStream s = this.getClass().getResourceAsStream("/exoplanets.json");
		assertEquals(expected , s);
	}
	@Test
	public void testGetHotestStar() {
		String s = mainClass.getHotestStar();
		String expected = "Hotest Star : V391 Peg b";
		//InputStream s = this.getClass().getResourceAsStream("/exoplanets.json");
		assertEquals(expected , s);
	}
	
	
	
} 
